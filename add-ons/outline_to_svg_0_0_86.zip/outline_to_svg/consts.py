METRIC_UNITS = {
    "KILOMETERS": "km",
    "METERS": "m",
    "CENTIMETERS": "cm",
    "MILLIMETERS": "mm",
}

IMPERIAL_UNITS = {"FEET": "ft", "INCHES": "in"}
